//1
//  let a = [1,2];
//  let div = document.createElement('div');
//  console.log(div);

// div.innerHTML = a

// //1.2
// let b = ['Anakin'];
// let div2 = document.createElement('div2');
// console.log(div2);

// div2.innerHTML = b;

//2
// let a = "Я хочу быть большим и сильным";

// console.log(a.length);

//3
//  let obj = {name: 'Ivan', age:35, gender: 'male',  job:'web-developer '};

// for(let key in obj){
//     console.log(`Значением свойства`,key,`является`,obj[key]);
// }

//4
// let str = 'я люблю торт';

// let word = "торт"

// if(word === "торт"){
//     console.log(true);
// }else{
//     console.log(false);
// }


//5
let num = prompt("Введите число");
let num2 = prompt("Введите число");
const result = num + num2;
const result2 = num * num2;

if (num > num2 ){
    alert(result);
}else if (num < num2 ){
    alert(result2);
}else if (num == num2 ){
    alert("числа одинаковые")
}


















