//1

console.log(Math.pow(2,10));

//2
console.log(Math.sqrt(245));

//3
console.log(Math.min(4, -2, 5, 19, -130, 0, 10));
console.log(Math.max(4, -2, 5, 19, -130, 0, 10));

//4
let a = Math.round(Math.random()*100);

console.log(a);


























