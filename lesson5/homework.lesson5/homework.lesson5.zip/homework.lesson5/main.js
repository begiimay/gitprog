// //1
// let num = prompt("Во скоько вы собираетеь прийти в магазин?");

// switch(num){
//     case "23":
//     case "24":
//     case "8":
//     case "7":
//     case "6":
//     case "5":
//     case "4":
//     case "3":
//     case "2":
//     case "1":
//         alert("В это время мы не работаем");
//         break;
//     case "9":
//     case "10":
//     case "11":
//         alert("Будем рады вас видеть");
//         break;
//     case "12":
//     case "13":    
//         alert("В это время у нас обед");
//         break;
//     case "14":
//     case "15":
//     case "16":
//     case "17":
//     case "18":
//     case "19":
//     case "20":
//     case "21":  
//     case "22":
//         alert("Будем рады вас видеть")  
// }

// //2
// let seasons = prompt("Введите месяц");

// switch(seasons){
//     case "декабрь":
//     case "январь":
//     case "февраль":
//         alert("Зима");
//         break;
//     case "март":
//     case "апрель":
//     case "май":
//          alert("Весна");  
//          break;
//     case "июнь":
//     case "июль":
//     case "август":
//          alert("Лето"); 
//          break;
//     case "сентябрь":
//     case "октябрь":
//     case "ноябрь":
//          alert("Осень");  
//          break;         
// }

// //3
// let time = prompt("Введите число");

// switch (time >= 0 && time <= 60 ){
//     case time >= 0 && time <= 15:
//         alert("Время относится к четверти часа");
//         break;
//     case time > 15 && time <= 30:
//         alert("Время относится к половине часа");
//         break;
//     case time > 30 && time <= 45:
//         alert("Время относится к 3/4 часа");
//         break;
//     case time >= 0 && time <= 15:
//         alert("Время относится к целому часу");
//         break;
// }

// //4
// let num2 = prompt("Введите число от 1 до 4");
// let result = "зима";
// let result2 = "весна";
// let result3= "лето";
// let result4 = "осень";

// switch(num2){
//     case '1':
//         alert(result);
//         break;
//     case '2':
//         alert(result2);
//         break;
//     case '3':
//         alert(result3);
//         break;
//     case '4':
//         alert(result4);    
//         break;
// }

// //5
// let month = 7;

// if (month >= 1 && month <= 3){
//     alert("Зима");
// }else if (month >= 4 && month <= 6){
//     alert("Весна");
// }else if(month >= 7 && month <= 9){
//     alert("Лето");
// }else if (month >= 10 && month <= 12){
//     alert("Осень");
// }

// //6
// let str = "abcde"

// if(a == str[0]){
//     alert("Да")
// }else{
//     alert("Нет")
// }

//7
let a = 1;
let b = 5;

if(a <= 1 || b >= 3){
   alert(a + b);
}else{
   alert(a -b);
}























