//1

var str1 = "Привет,";
var str2 = "Вася";

alert(str1 + str2);

//2

let name = prompt("Введите ваше имя");

alert(`Привет , ${name}`);

//3
let str3 = prompt("Введите ваш логин");

console.log(str3);

let str4 = prompt("Введите ваш пароль");

console.log(str4);

let str5 = prompt("Введите вашу дату рождения");

console.log(str5);

let str6 = prompt("Введите ваш пол");

console.log(str6);

//4
let num = 60 * 60;

alert(`в одном часе:${num} секунд`);