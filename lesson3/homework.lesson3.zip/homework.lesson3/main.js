//1
let num = prompt("Сколько часов вы спите?");

if (num <=  5 ){
    alert("Мало");
}else if (  10 > num >= 7){
    alert("Нормально");
}else if(num > 10){
    alert("Много");
}

//2
let con = confirm("Поняли ли вы данную тему?");

if (con == true){
    console.log("yes");
}else if (con == false){
    console.log("no");
}

//3
let b = 18;
let c = 20;

const result = b + c;

alert(result)

if (result == 38){
    alert("Верно");
}else {
    alert("Неверно");
}

//4
let str = "Codify";

if (str = str){
    alert("да ,это строка");
}else {
    alert("не знаю");
}

















